
<!DOCTYPE html>

<head>
    <meta charset="utf-8" />
    <title>Admin LogIn</title>
    <link rel="stylesheet" href="style3.css">
</head>

<body>

<center><div class="login">
<h1>Admin LogIn</h1>
<hr>
<form method ="post" action="login.php">

 
 <p class = "txt">
    <label><b>Username</b> <font color=red> * </font> </label> 
    <input type="text" placeholder="Enter Your Username" name="uname"  required><br>

    <label><b>Password</b> <font color=red> * </font> </label>
    <input type="password" placeholder="Enter Password" name="upassword"  required><br> <hr>
    
	<input type="submit" class="registerbtn" value="Login" name="sub">
</p>


</form>
</div>
</center>


</body>
</html>